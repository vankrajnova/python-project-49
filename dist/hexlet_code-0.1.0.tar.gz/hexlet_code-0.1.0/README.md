### Hexlet tests and linter status:
[![Actions Status](https://github.com/vankrajnova/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/vankrajnova/python-project-49/actions)

[maintainability](https://codeclimate.com/github/vankrajnova/python-project-49/maintainability)

[asciinema brain-even](https://asciinema.org/a/qLVBNjOn4Iw9yvZpITHo0CvXO)